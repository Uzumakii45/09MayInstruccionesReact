import logo from './logo.svg';
import './App.css';
import React from "react";
import Header from './components/header';
import Menu from './components/menu';




//Toso lo que se toma en {} es catalogado com javascrip
function App() {
  return( 
  <>
  <Header/>
  <Menu/>
  </>
)
       

}


export default App;
