export default function Menu() {
    return(
        <nav classNames="navbar navbar-expand-sm bg-dark navbar-dark">
  <div classNames="container-fluid">
    <ul classNames="navbar-nav">
      <li classNames="nav-item">
        <a classNames="nav-link active" href="#">Active</a>
      </li>
      <li classNames="nav-item">
        <a classNames="nav-link" href="#">Link</a>
      </li>
      <li classNames="nav-item">
        <a classNames="nav-link" href="#">Link</a>
      </li>
      <li classNames="nav-item">
        <a classNames="nav-link disabled" href="#">Disabled</a>
      </li>
    </ul>
  </div>
</nav>
    );
}