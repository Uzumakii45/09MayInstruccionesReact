import React from "react";

//Componente de clase 
class PrimerComponente extends React.Component {
    render();


}
